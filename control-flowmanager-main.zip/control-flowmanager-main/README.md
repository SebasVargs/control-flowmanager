# control-flowmanager
Sistema de gestion de decisiones y recursos.
